<?php
include 'db.php';
header('Content-Type: application/json');

$response = [];

$sql = "SELECT * FROM sensor_data ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $data = $result->fetch_assoc();
    $response = [
        'id' => $data['id'],
        'suhu' => $data['suhu'],
        'kelembaban' => $data['kelembaban'],
        'led' => $data['led'],
        'beep' => $data['beep'],
        'waktu' => $data['waktu']
    ];
} else {
    $response = ['error' => 'Data tidak ditemukan'];
}

echo json_encode($response);
?>
