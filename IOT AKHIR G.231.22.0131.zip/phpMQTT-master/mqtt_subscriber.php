<?php
require('phpMQTT.php');
require('db.php');

// Konfigurasi MQTT
$server = 'mqtt.revolusi-it.com';
$port = 1883;
$username = 'usm';
$password = 'usmjaya1';
$client_id = 'iot/G.231.22.0131-280301' . rand(); // Client ID unik

// Inisialisasi MQTT client
$mqtt = new Bluerhinos\phpMQTT($server, $port, $client_id);

// Coba koneksi ke broker
if (!$mqtt->connect(true, NULL, $username, $password)) {
    exit("❌ Gagal konek ke broker MQTT\n");
}

echo "✅ Terhubung ke broker MQTT...\n";

// Subscribe ke topik sesuai NIM
$mqtt->subscribe(["iot/G.231.22.0131" => ["qos" => 0, "function" => "procMsg"]]);

// Jalankan subscriber
while ($mqtt->proc()) {}

$mqtt->close();

// Fungsi untuk memproses pesan yang masuk
function procMsg($topic, $msg) {
    global $conn;
    echo "📥 Pesan diterima dari $topic: $msg\n";

    $data = json_decode($msg, true);
    if (!$data) {
        echo "⚠️ Format JSON tidak valid.\n";
        return;
    }

    // Ambil data dari payload
    $suhu = $data['suhu'] ?? 0;
    $kelembaban = $data['kelembaban'] ?? 0;
    $led = $data['LED'] ?? 0;
    $beep = $data['beep'] ?? 0;
    $status = $data['status'] ?? '-';
    $waktu = date('Y-m-d H:i:s');

    // Simpan ke database
    $stmt = $conn->prepare("INSERT INTO sensor_data (suhu, kelembaban, led, beep, status, waktu) VALUES (?, ?, ?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("ddiiss", $suhu, $kelembaban, $led, $beep, $status, $waktu);
        if ($stmt->execute()) {
            echo "✅ Data berhasil disimpan.\n";
        } else {
            echo "❌ Gagal menyimpan data: " . $stmt->error . "\n";
        }
        $stmt->close();
    } else {
        echo "❌ Statement gagal: " . $conn->error . "\n";
    }
}
?>
